#include <stdio.h>
#include <stdlib.h>
/*#define KEY_SIZE 256
#define DEBUG_MODE*/

void showMenu(int userType)
{
	char* options = "Logged in as Administrator";
	
	printf("\e[1;1H\e[2J");

	if(userType == 1)
	{
		/*administrator*/
		printf("%s \n\n", options);
		printf("1. Modify Details\t\t2. Modify User Details\t\t3. Encrypt/Decrypt "
		"\n4. Encrypt/Decrypt Users\t5. Exit\n\n");		
	}
	else if (userType == 2)
	{
		/*standard user*/
		options = "Logged in as standard user";
		printf("%s \n\n", options);
		printf("1. Modify Details\t\t2. Encrypt/Decrypt\t\t3. Exit\n\n");		
	}
	else if(userType == 3)
	{
		/*guest*/
		options = "Logged in as guest";
		printf("%s \n\n", options);
		printf("1. Compress/Decompress\t\t2. Exit\n\n");		
	}
}

/*int encrypt(char *file_name, char* password)
{
	
	char char_count = getCharacterCount(file_name);
	int i;

	#ifdef DEBUG_MODE
		printf("This is the character count in the file: %d\n", char_count);
	#endif

	if(char_count < 0)
	{
		return 0;
	}

	FILE* filep = NULL;
	filep = fopen(file_name, "w");

	if(filep == NULL){
		printf("Read error\n");
		return 0;
	}

	int key_length = strlen(password);
	char* encryption_key = '';

	for(i = 0; i < KEY_SIZE/key_length; i++) *//*test case when odd*/
	/*{
		encryption_key = encryption_key + password;
	}

	char ch;

	char* encryption_key = KEY_SIZE/key_length   

	for(i = 0; i < char_count; i++)
	{
		ch = fgetc();
		ch =  ch ^ encryption_key[i % key_length];
		fseek(filep, i-1, SEEK_END);
		fprintf(filep, "%c\n", ch );
	}

	return 1;

	fclose(filep);

}*/

/*int getCharacterCount(char* file_name){
	int count = 0;
	char ch;

	FILE* filep = NULL;
	filep = fopen(file_name, "w");

	if(filep == NULL){
		printf("Read error\n");
		return -1;
	}

	for(ch=fgetc(filep); ch!=EOF; ch=fgetc(filep))
	{	
		count++;
	}

	fclose(filep);
	return count;
}

int hash_password(char* password){

}*/