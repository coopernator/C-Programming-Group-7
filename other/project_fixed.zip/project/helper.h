#ifndef HELPER
#define HELPER

/*jonatan*/
void showMenu(int userType);

/*from monday 25/09/2017*/

/*james*/
void clear(void);

/*hoang??*/
void help();
#endif