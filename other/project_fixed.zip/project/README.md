# C-Programming-Group-7
Interactive file manager used for encryption and decryption of files.
