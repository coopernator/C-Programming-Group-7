struct fileDetail
{
	char* name;
	char* type;		/*encryption status*/
	double size;
	fileDetail_t* nextp;
};
typedef struct fileDetail fileDetail_t;


struct user
{	
	char* username;
	char* password;
	char* status;
	fileDetail_t* userFile;
	user_t* nextp;
 
};
typedef struct user user_t;



/*0 = no users, 1 = yes users, else = memory error*/
checkUser();

/*Create new user, saves user to database*/
createNewUser();

/*just shows the login menu */
void showLoginMenu(void);	


/*Returns 0 for incorrect, 1 for Admin, 2 for User, 3 for public, 4 for exit*/
loginAuthentication();

/*return an integer, or just display. 
input is status. 1 for Admin, 2 for User, 3 for public*/
showMenu(int status);

/**/
showAccountMenu()