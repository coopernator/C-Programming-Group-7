
/*Currently 'log off' is effectively quitting the program
Shouldn't be too hard to set it up so that log off prompts the user 
to log in again (or exit)

Need a way to return currentUser. Modify createNewUser, and modify login 
authentication functions
*/


int main()
{
	int status;
	int choice=0;
	int check = checkUser();
	char* currentUser;

	if(check==0)
	{
		createNewUser();
	}

	else if(check==1)
	{
		/*Default status is incorrect user/password*/
		status=0;

		while(status==0)
		{
			showLoginMenu();	
			/*Need a way to return the username as well*/
			status = loginAuthentication();

			if(status==0)
			{
				printf("Incorrect username or password, please try again\n");
			}
		}

		/*Admin User*/
		if(status==1)
		{

			while(choice!=5)
			{
				/*Depends on implementation of showMenu*/
				showMenu(1);
				scanf("%d",%choice);
				/*choice = showMenu(1);*/
				
				/*Modify account*/
				if(choice=1)
				{
					showAccountMenu();

					if()
					{
						fun1(/* user_t* user */)
					}
					if else()
					{
						fun2(/* user_t* user */)
					}
				}
				/*Modify user account*/
				if else(choice=2)
				{

				}
				/*encrypt/decrypt admin files*/
				if else(choice=3)
				{

				}
				/*encrypt/decrypt user files*/
				if else(choice=4)
				{

				}
				/*Logout*/
				if else(choice=5)
				{
					return 0;
				}
				else
				{
					printf(error);
					return 1;
				}
			}
		}

		/*normal user*/
		else if(status==2)
		{
			int choice;

			/*Depends on implementation of showMenu*/
			showMenu(2);
			scanf("%d",%choice);
			/*choice = showMenu(2);*/

			/*Modify account*/
			if(choice=1)
			{

			}			
			/*encrypt/decrypt  files*/
			if else(choice=2)
			{
				
			}
			/*Logout*/
			if else(choice=3)
			{
				return 0;
			}
			else
			{
				printf(error);
				return 1;
			}
		}

		/*public user*/
		else if(status==3)
		{
			int choice;

			/*Depends on implementation of showMenu*/
			showMenu(3);
			scanf("%d",%choice);
			/*choice = showMenu(3);*/
		
			/*compress files*/
			if else(choice=1)
			{

			}
			/*Logout*/
			if else(choic=2)
			{
				return 0;
			}
			else
			{
				printf(error);
				return 1;
			}
		}

		else if(status==4)
		{
			return 0;
		}

		else
		{
			printf("error");
			return 1;
		}
	}

	else
	{
		printf("error");
		return 1;
	}


	return 0;



	/*IF user mode*/



	/*IF user mode*/
	/*
	Determine whether its Admin, User, or Public

	Admin:
		printf("Enter password");
			Options:
			enter username
				change password
				add user
				add admin
				delete own admin account
				encrypt and compress all
				decrypt and decrompress all
				encrypt and compress chosen files
				encrypt and compress all
				decrypt and decrompress all
				Modify other users account
					select user: (putblic, user..c. .)
					


		
	User:
		enter user name, then enter password
			change password
			delete account
			




	Public:
		print,		only compression is availlable
		

	



	*/
}